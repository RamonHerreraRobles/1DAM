#usuario: Ramon Herrera

#********************************ENUNCIADO************************
#Crea un función EscribirCentrado, que reciba como parámetro un texto 
#y lo escriba centrado en pantalla (suponiendo una anchura de 80 columnas; 
#pista: deberás escribir 40 - longitud/2 espacios antes del texto). 
#Además subraya el mensaje utilizando el carácter =.

texto_herrera = input("Introduce el texto que deseas centrar: ")
from funciones import EscribirCentrado as centro_herrera 
(centro_herrera(texto_herrera))
