#usuario: Ramon Herrera

#********************************ENUNCIADO************************
#El día juliano correspondiente a una fecha es un número entero que 

from funciones import LeerFecha as fecha_herrera
from funciones import DiasDelMes as diasdelmes_herrera
from funciones import Calcular_Dia_Juliano as juliano_herrera
from funciones import Valido as valido_herrera

dia, mes, anio = fecha_herrera()

if valido_herrera(dia, mes, anio):
    dia_juliano = juliano_herrera(dia, mes, anio)
    print("El día juliano correspondiente a la fecha {}-{}-{} es: {}".format(dia, mes, anio, dia_juliano))
else:
    print("La fecha ingresada no es válida.")